import type React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import {
  ContactShadows,
  Environment,
  Lightformer,
  OrbitControls,
  RoundedBox,
} from "@react-three/drei";
import { Bloom, EffectComposer, Vignette } from "@react-three/postprocessing";
import * as THREE from "three";
import { REEL_STRIPS, SYMBOLS, type SymbolId } from "@/lib/slot";
import {
  makeCarpetTexture,
  makeMarqueeTexture,
  makeShadeTexture,
  makeSymbolTexture,
} from "./textures";
import { COIN_RADIUS, COIN_THICK, MAX_COINS, coinCountForWin, spawnCoins, stepCoins, type Coin } from "./coinSim";
import { INITIAL_STOPS, REEL_SPIN_MS, type SpinCommand } from "./useSlotGame";

import {
  BASE_H, BODY_D, BODY_W, CELL_H, FRONT_Z, REEL_R, REEL_W, REEL_XS, REEL_Z, SPIN_TURNS, STEP, STOPS, TOP_Y, TRAY, WIN_H, WIN_W, WIN_Y,
} from "./dims";
import { CabinetExtras, Paylines, WinSparkles } from "./Extras";

/* ---------- materials ---------- */
const PALETTE = {
  paint: "#8a0f19",
  chrome: "#e6e6e6",
  gold: "#d6a844",
  black: "#0d0b0c",
  bulb: "#ffcf6b",
  ball: "#c3121c",
  spin: "#e3242b",
  bet: "#f0a52a",
  payline: "#ff2a2a",
};

function useMaterials() {
  return useMemo(
    () => ({
      paint: new THREE.MeshPhysicalMaterial({
        color: PALETTE.paint,
        roughness: 0.32,
        metalness: 0.35,
        clearcoat: 1,
        clearcoatRoughness: 0.08,
      }),
      chrome: new THREE.MeshStandardMaterial({ color: PALETTE.chrome, metalness: 1, roughness: 0.1, envMapIntensity: 1.6 }),
      gold: new THREE.MeshStandardMaterial({ color: PALETTE.gold, metalness: 1, roughness: 0.22, envMapIntensity: 1.5 }),
      black: new THREE.MeshStandardMaterial({ color: PALETTE.black, roughness: 0.55, metalness: 0.2 }),
      glass: new THREE.MeshPhysicalMaterial({
        color: "#ffffff",
        roughness: 0.02,
        metalness: 0,
        transparent: true,
        opacity: 0.06,
        envMapIntensity: 0.9,
        clearcoat: 1,
      }),
      ball: new THREE.MeshPhysicalMaterial({
        color: PALETTE.ball,
        roughness: 0.15,
        clearcoat: 1,
        clearcoatRoughness: 0.05,
      }),
    }),
    [],
  );
}
type Mats = ReturnType<typeof useMaterials>;

/* ---------- reels ---------- */
const easeOutBack = (t: number) => {
  const c1 = 0.9;
  const c3 = c1 + 1;
  return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2;
};

function Reel({
  index,
  textures,
  command,
}: {
  index: number;
  textures: Record<SymbolId, THREE.Texture>;
  command: SpinCommand;
}) {
  const group = useRef<THREE.Group>(null);
  const strip = REEL_STRIPS[index]!;
  const anim = useRef({
    angle: -INITIAL_STOPS[index]! * STEP,
    from: 0,
    to: 0,
    start: 0,
    duration: 1,
    active: false,
  });
  const materials = useMemo(
    () =>
      Object.fromEntries(
        SYMBOLS.map((s) => [s.id, new THREE.MeshStandardMaterial({ map: textures[s.id], roughness: 0.6, envMapIntensity: 0.35 })]),
      ) as unknown as Record<SymbolId, THREE.Material>,
    [textures],
  );

  useEffect(() => {
    if (command.id === 0) return;
    const a = anim.current;
    const base = -command.stops[index]! * STEP;
    const minTo = a.angle + Math.PI * 2 * SPIN_TURNS[index]!;
    a.from = a.angle;
    a.to = base + Math.ceil((minTo - base) / (Math.PI * 2)) * Math.PI * 2;
    a.start = performance.now();
    a.duration = REEL_SPIN_MS[index]!;
    a.active = true;
  }, [command, index]);

  useFrame(() => {
    const a = anim.current;
    if (a.active) {
      const t = Math.min(1, (performance.now() - a.start) / a.duration);
      a.angle = a.from + (a.to - a.from) * easeOutBack(t);
      if (t >= 1) {
        a.angle = a.to;
        a.active = false;
      }
    }
    if (group.current) group.current.rotation.x = a.angle;
  });

  return (
    <group position={[REEL_XS[index]!, WIN_Y, REEL_Z]}>
      <group ref={group}>
        <mesh rotation-z={Math.PI / 2}>
          <cylinderGeometry args={[REEL_R * 0.97, REEL_R * 0.97, REEL_W * 0.98, STOPS]} />
          <meshStandardMaterial color="#cfc3a6" roughness={0.8} />
        </mesh>
        {strip.map((id, i) => (
          <group key={i} rotation-x={i * STEP}>
            <mesh position-z={REEL_R} material={materials[id]}>
              <planeGeometry args={[REEL_W, CELL_H]} />
            </mesh>
          </group>
        ))}
      </group>
      {/* chrome hub caps */}
      {[-1, 1].map((side) => (
        <mesh key={side} position-x={side * (REEL_W / 2 + 0.005)} rotation-z={Math.PI / 2}>
          <cylinderGeometry args={[REEL_R * 0.99, REEL_R * 0.99, 0.01, 40]} />
          <meshStandardMaterial color="#1a1515" metalness={0.6} roughness={0.4} />
        </mesh>
      ))}
    </group>
  );
}

/* ---------- cabinet ---------- */
function Bulbs({ excited }: { excited: boolean }) {
  const matA = useMemo(
    () => new THREE.MeshStandardMaterial({ color: PALETTE.bulb, emissive: PALETTE.bulb, toneMapped: false }),
    [],
  );
  const matB = useMemo(() => matA.clone(), [matA]);
  const positions = useMemo(() => {
    const pts: [number, number, number][] = [];
    const w = 2.12;
    const h = 0.78;
    const cy = 3.93;
    const z = FRONT_Z + 0.03;
    const nx = 13;
    const ny = 4;
    for (let i = 0; i <= nx; i++) {
      const x = -w / 2 + (w * i) / nx;
      pts.push([x, cy + h / 2, z], [x, cy - h / 2, z]);
    }
    for (let j = 1; j < ny; j++) {
      const y = cy - h / 2 + (h * j) / ny;
      pts.push([-w / 2, y, z], [w / 2, y, z]);
    }
    return pts;
  }, []);
  useFrame(({ clock }) => {
    const speed = excited ? 14 : 3.2;
    const phase = Math.sin(clock.elapsedTime * speed);
    matA.emissiveIntensity = 0.4 + 2.6 * Math.max(0, phase);
    matB.emissiveIntensity = 0.4 + 2.6 * Math.max(0, -phase);
  });
  return (
    <>
      {positions.map((p, i) => (
        <mesh key={i} position={p} material={i % 4 < 2 ? matA : matB}>
          <sphereGeometry args={[0.038, 16, 12]} />
        </mesh>
      ))}
    </>
  );
}

function hoverCursor(on: boolean) {
  return () => {
    document.body.style.cursor = on ? "pointer" : "";
  };
}

function PushButton({
  position,
  color,
  radius,
  enabled,
  onPress,
  label,
}: {
  position: [number, number, number];
  color: string;
  radius: number;
  enabled: boolean;
  onPress: () => void;
  label: string;
}) {
  const ref = useRef<THREE.Mesh>(null);
  const pressedAt = useRef(-10);
  useFrame(() => {
    const t = performance.now() / 1000 - pressedAt.current;
    if (ref.current) ref.current.position.y = 0.04 - (t < 0.15 ? 0.025 : 0);
  });
  const click = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    pressedAt.current = performance.now() / 1000;
    onPress();
  };
  return (
    <group position={position} name={label}>
      <mesh>
        <cylinderGeometry args={[radius * 1.25, radius * 1.3, 0.04, 40]} />
        <meshStandardMaterial color={PALETTE.chrome} metalness={1} roughness={0.15} />
      </mesh>
      <mesh
        ref={ref}
        onClick={click}
        onPointerOver={hoverCursor(true)}
        onPointerOut={hoverCursor(false)}
      >
        <cylinderGeometry args={[radius, radius, 0.07, 40]} />
        <meshPhysicalMaterial
          color={color}
          emissive={color}
          emissiveIntensity={enabled ? 0.9 : 0.1}
          roughness={0.25}
          clearcoat={1}
          transmission={0}
        />
      </mesh>
    </group>
  );
}

function Lever({ mats, command, onPull, enabled }: { mats: Mats; command: SpinCommand; onPull: () => void; enabled: boolean }) {
  const arm = useRef<THREE.Group>(null);
  const start = useRef(-10);
  useEffect(() => {
    if (command.id > 0) start.current = performance.now();
  }, [command.id]);
  useFrame(() => {
    const t = (performance.now() - start.current) / 1000;
    let a = 0;
    if (t < 0.22) a = (t / 0.22) * 1.05;
    else if (t < 0.75) a = 1.05 * (1 - easeOutBack((t - 0.22) / 0.53));
    if (arm.current) arm.current.rotation.x = a;
  });
  return (
    <group position={[BODY_W / 2 + 0.1, 2.15, 0.15]}>
      <mesh rotation-z={Math.PI / 2} material={mats.chrome}>
        <cylinderGeometry args={[0.16, 0.16, 0.2, 32]} />
      </mesh>
      <mesh rotation-z={Math.PI / 2} position-x={0.11} material={mats.black}>
        <cylinderGeometry args={[0.1, 0.1, 0.04, 32]} />
      </mesh>
      <group ref={arm} position-x={0.14}>
        <mesh position-y={0.6} material={mats.chrome}>
          <cylinderGeometry args={[0.032, 0.04, 1.2, 20]} />
        </mesh>
        <mesh
          position-y={1.25}
          material={mats.ball}
          onClick={(e) => {
            e.stopPropagation();
            if (enabled) onPull();
          }}
          onPointerOver={hoverCursor(true)}
          onPointerOut={hoverCursor(false)}
        >
          <sphereGeometry args={[0.13, 40, 28]} />
        </mesh>
      </group>
    </group>
  );
}

function Cabinet({
  mats,
  excited,
}: {
  mats: Mats;
  excited: boolean;
}) {
  const marquee = useMemo(() => makeMarqueeTexture(), []);
  const shade = useMemo(() => makeShadeTexture(), []);
  const winBottom = WIN_Y - WIN_H / 2;
  const winTop = WIN_Y + WIN_H / 2;
  const pillarW = (BODY_W - WIN_W) / 2;
  return (
    <group>
      {/* pedestal */}
      <RoundedBox args={[BODY_W + 0.15, BASE_H, BODY_D + 0.15]} radius={0.06} position-y={BASE_H / 2} material={mats.black} />
      <mesh position={[0, BASE_H - 0.03, FRONT_Z + 0.076]} material={mats.gold}>
        <boxGeometry args={[BODY_W + 0.15, 0.05, 0.01]} />
      </mesh>
      {/* lower body */}
      <mesh position={[0, (BASE_H + winBottom) / 2, 0]} material={mats.paint}>
        <boxGeometry args={[BODY_W, winBottom - BASE_H, BODY_D]} />
      </mesh>
      {/* coin chute + tray */}
      <mesh position={[0, TRAY.floorY + 0.28, FRONT_Z + 0.004]} material={mats.black}>
        <boxGeometry args={[0.8, 0.16, 0.01]} />
      </mesh>
      <mesh position={[0, TRAY.floorY + 0.37, FRONT_Z + 0.02]} material={mats.chrome}>
        <boxGeometry args={[0.9, 0.035, 0.04]} />
      </mesh>
      <mesh position={[0, TRAY.floorY - 0.015, (TRAY.minZ + TRAY.maxZ) / 2]} material={mats.chrome}>
        <boxGeometry args={[TRAY.maxX - TRAY.minX + 0.06, 0.03, TRAY.maxZ - FRONT_Z + 0.03]} />
      </mesh>
      <mesh position={[0, TRAY.floorY + 0.012, TRAY.maxZ + 0.015]} material={mats.chrome}>
        <boxGeometry args={[TRAY.maxX - TRAY.minX + 0.06, 0.05, 0.03]} />
      </mesh>
      {[-1, 1].map((sd) => (
        <mesh key={sd} position={[sd * (TRAY.maxX + 0.015), TRAY.floorY + 0.012, (FRONT_Z + TRAY.maxZ) / 2]} material={mats.chrome}>
          <boxGeometry args={[0.03, 0.05, TRAY.maxZ - FRONT_Z + 0.03]} />
        </mesh>
      ))}
      {/* pillars + upper band */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (BODY_W / 2 - pillarW / 2), WIN_Y, 0]} material={mats.paint}>
          <boxGeometry args={[pillarW, WIN_H, BODY_D]} />
        </mesh>
      ))}
      <mesh position={[0, (winTop + TOP_Y) / 2, 0]} material={mats.paint}>
        <boxGeometry args={[BODY_W, TOP_Y - winTop, BODY_D]} />
      </mesh>
      <mesh position={[0, TOP_Y - 0.05, FRONT_Z + 0.006]} material={mats.gold}>
        <boxGeometry args={[BODY_W, 0.07, 0.01]} />
      </mesh>
      {/* reel cavity */}
      <mesh position={[0, WIN_Y, -FRONT_Z + 0.06]} material={mats.black}>
        <boxGeometry args={[WIN_W, WIN_H, 0.1]} />
      </mesh>
      {[-0.32, 0.32].map((x) => (
        <mesh key={x} position={[x, WIN_Y, 0.2]} material={mats.black}>
          <boxGeometry args={[0.05, WIN_H, 1.3]} />
        </mesh>
      ))}
      <pointLight position={[0, winTop + 0.05, 0.7]} intensity={0.9} distance={2} decay={2} color="#ffe6bf" />
      <mesh position={[0, WIN_Y, FRONT_Z - 0.02]}>
        <planeGeometry args={[WIN_W, WIN_H]} />
        <meshBasicMaterial map={shade} transparent depthWrite={false} />
      </mesh>
      {/* glass */}
      <mesh position={[0, WIN_Y, FRONT_Z + 0.005]} material={mats.glass}>
        <planeGeometry args={[WIN_W, WIN_H]} />
      </mesh>
      {/* chrome window frame */}
      {[winTop + 0.03, winBottom - 0.03].map((y) => (
        <mesh key={y} position={[0, y, FRONT_Z + 0.02]} material={mats.chrome}>
          <boxGeometry args={[WIN_W + 0.12, 0.06, 0.05]} />
        </mesh>
      ))}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (WIN_W / 2 + 0.03), WIN_Y, FRONT_Z + 0.02]} material={mats.chrome}>
          <boxGeometry args={[0.06, WIN_H + 0.12, 0.05]} />
        </mesh>
      ))}
      {/* side chrome edges */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * BODY_W / 2, (BASE_H + TOP_Y) / 2, FRONT_Z]} material={mats.chrome}>
          <cylinderGeometry args={[0.035, 0.035, TOP_Y - BASE_H, 16]} />
        </mesh>
      ))}
      {/* button deck */}
      <group position={[0, winBottom - 0.2, FRONT_Z + 0.22]} rotation-x={0.28}>
        <RoundedBox args={[BODY_W - 0.1, 0.1, 0.45]} radius={0.03} material={mats.black} />
        <mesh position={[0, 0.0, 0.226]} material={mats.chrome}>
          <boxGeometry args={[BODY_W - 0.1, 0.06, 0.01]} />
        </mesh>
      </group>
      {/* marquee */}
      <RoundedBox args={[BODY_W, 0.95, BODY_D]} radius={0.08} position-y={TOP_Y + 0.475} material={mats.paint} />
      <mesh position={[0, 3.93, FRONT_Z + 0.005]}>
        <planeGeometry args={[2.05, 0.72]} />
        <meshStandardMaterial
          map={marquee}
          emissiveMap={marquee}
          emissive="#ffffff"
          emissiveIntensity={excited ? 1.1 : 0.75}
          roughness={0.3}
        />
      </mesh>
      <Bulbs excited={excited} />
    </group>
  );
}

/* ---------- coin shower ---------- */
function CoinShower({ payout }: { payout: { id: number; win: number } }) {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const coins = useRef<Coin[]>([]);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const mat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#f4c654", metalness: 1, roughness: 0.2, envMapIntensity: 1.8 }),
    [],
  );

  useEffect(() => {
    if (payout.win <= 0) return;
    coins.current = spawnCoins(coinCountForWin(payout.win), [0, TRAY.floorY + 0.28, FRONT_Z + 0.03]);
  }, [payout.id, payout.win]);

  useFrame((_, delta) => {
    const m = mesh.current;
    if (!m) return;
    stepCoins(coins.current, Math.min(delta, 0.05), TRAY);
    let n = 0;
    for (const c of coins.current) {
      if (c.delay > 0) continue;
      dummy.position.set(c.p[0], c.p[1], c.p[2]);
      dummy.rotation.set(c.rot[0], c.rot[1], c.rot[2]);
      dummy.updateMatrix();
      m.setMatrixAt(n++, dummy.matrix);
    }
    m.count = n;
    m.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={mesh} args={[undefined, mat, MAX_COINS]} frustumCulled={false}>
      <cylinderGeometry args={[COIN_RADIUS, COIN_RADIUS, COIN_THICK, 28]} />
    </instancedMesh>
  );
}

/* ---------- environment ---------- */
function Floor() {
  const carpet = useMemo(() => makeCarpetTexture(), []);
  return (
    <mesh rotation-x={-Math.PI / 2} receiveShadow>
      <planeGeometry args={[60, 60]} />
      <meshStandardMaterial map={carpet} roughness={0.95} />
    </mesh>
  );
}

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeGlowTexture() {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.35, "rgba(255,255,255,0.55)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

/** Out-of-focus casino lights behind the machine. */
function CasinoBokeh() {
  const glow = useMemo(() => makeGlowTexture(), []);
  const lights = useMemo(() => {
    const rand = mulberry32(7);
    const colors = ["#ffb347", "#ff5a45", "#3fc6bd", "#ffe2a8"];
    return Array.from({ length: 40 }, () => ({
      p: [(rand() - 0.5) * 40, 1 + rand() * 7, -14 - rand() * 14] as [number, number, number],
      s: 0.5 + rand() * 1.1,
      c: colors[Math.floor(rand() * colors.length)]!,
      o: 0.06 + rand() * 0.16,
    }));
  }, [glow]);
  return (
    <>
      {lights.map((l, k) => (
        <sprite key={k} position={l.p} scale={[l.s, l.s, 1]}>
          <spriteMaterial
            map={glow}
            color={l.c}
            transparent
            opacity={l.o}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
            fog={false}
            toneMapped={false}
          />
        </sprite>
      ))}
    </>
  );
}

function CameraRig() {
  const { camera, size } = useThree();
  const controls = useRef<React.ComponentRef<typeof OrbitControls>>(null);
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    const aspect = size.width / size.height;
    const vHalf = (cam.fov * Math.PI) / 360;
    const hHalf = Math.atan(Math.tan(vHalf) * aspect);
    const portrait = aspect < 1;
    const d = Math.max(1.85 / Math.tan(hHalf), 2.6 / Math.tan(vHalf)) + 1.2;
    const targetY = portrait ? 1.55 : 2.25;
    const az = 0.32;
    cam.position.set(Math.sin(az) * d, targetY + 0.9, Math.cos(az) * d);
    controls.current?.target.set(0, targetY, 0);
    controls.current?.update();
  }, [camera, size]);
  return (
    <OrbitControls
      ref={controls}
      enablePan={false}
      enableZoom={false}
      enableDamping
      minAzimuthAngle={-0.7}
      maxAzimuthAngle={0.7}
      minPolarAngle={1.15}
      maxPolarAngle={1.62}
      rotateSpeed={0.5}
    />
  );
}

function ReadySignal({ onReady }: { onReady: () => void }) {
  const fired = useRef(false);
  useFrame(() => {
    if (!fired.current) {
      fired.current = true;
      requestAnimationFrame(onReady);
    }
  });
  return null;
}

function SceneContent({
  command,
  spinning,
  won,
  canSpin,
  onSpin,
  onBet,
  payout,
  lines,
  winLines,
  bigWin,
  display,
  onReady,
  fontsReady,
}: SceneProps & { onReady: () => void; fontsReady: boolean }) {
  const mats = useMaterials();
  const textures = useMemo(() => {
    const aspect = REEL_W / CELL_H;
    return Object.fromEntries(SYMBOLS.map((s) => [s.id, makeSymbolTexture(s.id, aspect)])) as unknown as Record<
      SymbolId,
      THREE.Texture
    >;
    // fontsReady re-draws textures once the display font has loaded
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fontsReady]);

  return (
    <>
      <color attach="background" args={["#0a0607"]} />
      <fog attach="fog" args={["#0a0607", 12, 34]} />
      <ambientLight intensity={0.35} />
      <hemisphereLight args={["#ffe7c4", "#2a0a10", 0.6]} />
      <spotLight position={[2.5, 9, 6]} angle={0.42} penumbra={0.7} intensity={180} color="#fff1d6" />
      <directionalLight position={[3, 4, 9]} intensity={0.6} color="#fff3e0" />
      <Environment resolution={256} environmentIntensity={1.25}>
        <Lightformer intensity={2.2} position={[0, 6, 2]} scale={[8, 2, 1]} rotation-x={Math.PI / 2} />
        <Lightformer intensity={1.4} color="#ffcf8a" position={[-5, 2, 3]} rotation-y={Math.PI / 2} scale={[10, 1.2, 1]} />
        <Lightformer intensity={1.2} color="#ff5a4a" position={[5, 1.5, 1]} rotation-y={-Math.PI / 2} scale={[10, 0.8, 1]} />
        <Lightformer intensity={1.3} position={[0, 2, 8]} scale={[6, 3, 1]} />
        <Lightformer intensity={0.8} color="#ffb070" position={[0, -1, 4]} rotation-x={-Math.PI / 3} scale={[8, 2, 1]} />
      </Environment>

      <Cabinet mats={mats} excited={spinning || won} />
      <CabinetExtras credits={display.credits} bet={display.bet} win={display.win} excited={spinning || won} goldMat={mats.gold} chromeMat={mats.chrome} />
      <Paylines lines={lines} winLines={winLines} />
      <WinSparkles won={won} big={bigWin} />
      {REEL_STRIPS.map((_, i) => (
        <Reel key={i} index={i} textures={textures} command={command} />
      ))}
      <Lever mats={mats} command={command} onPull={onSpin} enabled={canSpin} />
      <group position={[0, WIN_Y - WIN_H / 2 - 0.2, FRONT_Z + 0.22]} rotation-x={0.28}>
        <PushButton label="bet-down" position={[-0.75, 0.05, 0.02]} color={PALETTE.bet} radius={0.07} enabled={!spinning} onPress={() => onBet(-1)} />
        <PushButton label="bet-up" position={[-0.45, 0.05, 0.02]} color={PALETTE.bet} radius={0.07} enabled={!spinning} onPress={() => onBet(1)} />
        <PushButton label="spin" position={[0.6, 0.05, 0.02]} color={PALETTE.spin} radius={0.13} enabled={canSpin} onPress={onSpin} />
      </group>

      <CoinShower payout={payout} />
      <Floor />
      <ContactShadows position-y={0.005} scale={8} blur={2.6} opacity={0.8} far={4} resolution={512} />
      <CasinoBokeh />
      <CameraRig />
      <EffectComposer multisampling={4}>
        <Bloom mipmapBlur intensity={0.75} luminanceThreshold={1} luminanceSmoothing={0.2} />
        <Vignette offset={0.25} darkness={0.75} />
      </EffectComposer>
      <ReadySignal onReady={onReady} />
    </>
  );
}

export interface SceneProps {
  command: SpinCommand;
  spinning: boolean;
  won: boolean;
  canSpin: boolean;
  onSpin: () => void;
  onBet: (delta: number) => void;
  payout: { id: number; win: number };
  lines: number;
  winLines: number[];
  bigWin: boolean;
  display: { credits: number; bet: number; win: number };
}

export default function SlotScene(props: SceneProps) {
  const [ready, setReady] = useState(false);
  const [fontsReady, setFontsReady] = useState(false);
  useEffect(() => {
    let alive = true;
    const done = () => alive && setFontsReady(true);
    Promise.all([document.fonts.load("120px Bungee")]).then(done, done);
    const t = window.setTimeout(done, 2500);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, []);

  return (
    <div className="absolute inset-0" data-scene-ready={ready && fontsReady ? "" : undefined}>
      <Canvas dpr={[1, 2]} camera={{ fov: 38, position: [0, 3, 10], near: 0.1, far: 80 }} gl={{ antialias: true }}>
        <SceneContent {...props} onReady={() => setReady(true)} fontsReady={fontsReady} />
      </Canvas>
    </div>
  );
}
