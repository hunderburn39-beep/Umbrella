import { lazy, Suspense, useState } from "react";
import { Minus, Music, Music2, Plus, RotateCcw, Trophy, Volume2, VolumeX, X } from "lucide-react";
import { MAX_BET, MIN_BET, PAYLINES, SYMBOLS, TWO_CHERRIES_MULTIPLIER } from "@/lib/slot";
import { cn } from "@/lib/utils";
import { SymbolFace } from "./SymbolFace";
import { useSlotGame } from "./useSlotGame";

const SlotScene = lazy(() => import("./SlotScene"));

function Loading() {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <p className="font-display text-lg text-gold animate-pulse">A ligar a máquina…</p>
    </div>
  );
}

export function SlotGame3D() {
  const g = useSlotGame();
  const [showPays, setShowPays] = useState(false);
  const won = !!g.result && g.result.total > 0;
  const bigWin = !!g.result && (g.result.kind === "jackpot" || g.result.kind === "three");
  const winLines = g.result?.lineWins.map((w) => w.line) ?? [];

  const lineText =
    g.result && g.result.lineWins.length > 0
      ? g.result.lineWins.map((w) => `L${w.line} +${w.win}`).join(" · ")
      : "";

  const message = g.spinning
    ? "A girar…"
    : g.broke
      ? "Sem créditos! Recarrega para continuar."
      : !g.canSpin && !g.spinning
        ? "Aposta maior que os créditos: baixa a aposta ou as linhas"
        : g.result?.kind === "jackpot"
          ? `JACKPOT! +${g.result.total}`
          : won
            ? `Ganhaste ${g.result!.total} créditos!`
            : g.result
              ? "Quase… tenta outra vez!"
              : "Puxa a alavanca ou carrega em GIRAR";

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-felt-deep">
        <Suspense fallback={<Loading />}>
          <SlotScene
            command={g.command}
            spinning={g.spinning}
            won={won}
            canSpin={g.canSpin}
            onSpin={g.spin}
            onBet={g.changeBet}
            payout={{ id: g.command.id, win: won ? g.result!.total : 0 }}
            lines={g.lines}
            winLines={winLines}
            bigWin={bigWin}
            display={{ credits: g.credits, bet: g.cost, win: g.lastWin }}
          />
        </Suspense>

      {/* top bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 flex justify-between p-3">
        <button
          onClick={() => setShowPays(true)}
          className="pointer-events-auto flex items-center gap-2 rounded-full bg-card/70 px-3 py-2 text-xs uppercase tracking-widest text-gold backdrop-blur hover:bg-card"
        >
          <Trophy className="size-4" /> Prémios
        </button>
        <div className="pointer-events-auto flex gap-2">
          <button
            onClick={g.toggleMusic}
            aria-label={g.music ? "Desligar música" : "Ligar música"}
            className={cn(
              "rounded-full bg-card/70 p-2 backdrop-blur hover:bg-card",
              g.music ? "text-gold" : "text-muted-foreground",
            )}
          >
            {g.music ? <Music className="size-5" /> : <Music2 className="size-5 opacity-50" />}
          </button>
          <button
            onClick={g.toggleMute}
            aria-label={g.muted ? "Ligar efeitos de som" : "Desligar efeitos de som"}
            className="rounded-full bg-card/70 p-2 text-gold backdrop-blur hover:bg-card"
          >
            {g.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </button>
        </div>
      </div>

      {/* HUD */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-felt-deep via-felt-deep/85 to-transparent px-3 pb-4 pt-10">
        <div className="pointer-events-auto mx-auto max-w-md">
          <div
            key={`${g.command.id}-${g.result?.kind ?? "x"}`}
            aria-live="polite"
            className={cn("mb-2 min-h-7 text-center", won && "animate-win-pop")}
          >
            <p className={cn("font-display text-lg", won ? "text-gold" : "text-foreground/85")}>{message}</p>
            {lineText && <p className="text-xs tracking-wider text-gold/80">{lineText}</p>}
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <Readout label="Créditos" value={g.credits} />
            <Readout label="Aposta total" value={g.cost} />
            <Readout label="Prémio" value={g.lastWin} glow={won} />
          </div>
          <div className="mt-3 flex items-center gap-2">
            <div className="flex flex-col items-center rounded-2xl bg-card/80 px-1 pb-1 pt-0.5">
              <span className="text-[9px] uppercase tracking-widest text-muted-foreground">Por linha</span>
              <div className="flex items-center">
                <RoundButton label="Diminuir aposta" disabled={g.spinning || g.bet <= MIN_BET} onClick={() => g.changeBet(-1)}>
                  <Minus className="size-4" />
                </RoundButton>
                <span className="w-7 text-center font-display text-lg text-gold">{g.bet}</span>
                <RoundButton label="Aumentar aposta" disabled={g.spinning || g.bet >= MAX_BET} onClick={() => g.changeBet(1)}>
                  <Plus className="size-4" />
                </RoundButton>
              </div>
            </div>
            <button
              onClick={g.cycleLines}
              disabled={g.spinning}
              aria-label="Mudar número de linhas"
              className="flex h-[3.4rem] w-16 flex-col items-center justify-center rounded-2xl bg-card/80 text-gold transition hover:bg-card active:scale-95 disabled:opacity-50"
            >
              <span className="text-[9px] uppercase tracking-widest text-muted-foreground">Linhas</span>
              <span className="font-display text-lg leading-none">{g.lines}</span>
            </button>
            {g.broke ? (
              <button
                onClick={g.refill}
                className="flex h-14 flex-1 items-center justify-center gap-2 rounded-full bg-gold-gradient font-display text-lg text-primary-foreground shadow-gold-glow transition active:scale-95"
              >
                <RotateCcw className="size-5" /> Recarregar
              </button>
            ) : (
              <button
                onClick={g.spin}
                disabled={!g.canSpin}
                className="h-14 flex-1 rounded-full bg-gold-gradient font-display text-2xl tracking-wider text-primary-foreground shadow-gold-glow transition hover:brightness-110 active:scale-95 disabled:opacity-60 disabled:active:scale-100"
              >
                {g.spinning ? "…" : "GIRAR"}
              </button>
            )}
          </div>
          <button
            onClick={g.maxBet}
            disabled={g.spinning || g.credits < MIN_BET}
            className="mt-2 w-full text-center text-xs uppercase tracking-widest text-gold/70 hover:text-gold disabled:opacity-40"
          >
            Aposta máxima · créditos virtuais, sem dinheiro real
          </button>
        </div>
      </div>

      {showPays && <Paytable onClose={() => setShowPays(false)} />}
    </div>
  );
}

function Readout({ label, value, glow }: { label: string; value: number; glow?: boolean }) {
  return (
    <div className="rounded-xl bg-card/80 px-2 py-1.5 backdrop-blur">
      <div className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground">{label}</div>
      <div className={cn("font-display text-xl tabular-nums text-gold", glow && "animate-win-pop")}>{value}</div>
    </div>
  );
}

function RoundButton({
  children,
  label,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      aria-label={label}
      className="flex size-9 items-center justify-center rounded-full bg-secondary text-gold transition hover:bg-muted active:scale-90 disabled:opacity-40"
      {...props}
    >
      {children}
    </button>
  );
}

function LineDiagram({ rows }: { rows: [number, number, number] }) {
  return (
    <div className="grid grid-cols-3 gap-0.5 rounded bg-background/60 p-1">
      {[0, 1, 2].map((r) =>
        [0, 1, 2].map((c) => (
          <span key={`${r}-${c}`} className={cn("size-2.5 rounded-sm", rows[c] === r ? "bg-gold" : "bg-muted")} />
        )),
      )}
    </div>
  );
}

function Paytable({ onClose }: { onClose: () => void }) {
  return (
    <div className="absolute inset-0 z-10 flex items-center justify-center overflow-y-auto bg-background/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <section
        className="relative my-auto w-full max-w-sm rounded-2xl border border-border bg-card p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} aria-label="Fechar" className="absolute right-3 top-3 text-muted-foreground hover:text-foreground">
          <X className="size-5" />
        </button>
        <h2 className="text-center font-display text-sm tracking-widest text-gold">Tabela de prémios</h2>
        <ul className="mt-4 space-y-2 text-sm">
          {[...SYMBOLS].reverse().map((s) => (
            <li key={s.id} className="flex items-center justify-between">
              <span className="flex gap-1 text-xl">
                <SymbolFace id={s.id} />
                <SymbolFace id={s.id} />
                <SymbolFace id={s.id} />
              </span>
              <span className="font-display text-gold">×{s.payout}</span>
            </li>
          ))}
          <li className="flex items-center justify-between">
            <span className="flex gap-1 text-xl">
              <SymbolFace id="cherry" />
              <SymbolFace id="cherry" />
            </span>
            <span className="font-display text-gold">×{TWO_CHERRIES_MULTIPLIER}</span>
          </li>
        </ul>
        <h3 className="mt-5 text-center font-display text-xs tracking-widest text-gold">5 linhas de prémio</h3>
        <ul className="mt-3 grid grid-cols-5 gap-2 text-center text-[10px] text-muted-foreground">
          {PAYLINES.map((p) => (
            <li key={p.id} className="flex flex-col items-center gap-1">
              <LineDiagram rows={p.rows} />
              <span>
                {p.id}. {p.name}
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Cada linha ativa custa a aposta por linha. Prémio = aposta por linha × multiplicador, somado em todas as linhas.
        </p>
      </section>
    </div>
  );
}
