import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Sparkles } from "@react-three/drei";
import * as THREE from "three";
import { PAYLINES } from "@/lib/slot";
import { BASE_H, BODY_W, FRONT_Z, REEL_R, REEL_XS, STEP, TOP_Y, TRAY, WIN_H, WIN_W, WIN_Y } from "./dims";

/** Height of each visible row's centre on the glass (row 0 = top). */
const ROW_Y = [REEL_R * Math.sin(STEP), 0, -REEL_R * Math.sin(STEP)];
export const LINE_COLORS = ["#ff3030", "#ffc83a", "#35d0c0", "#5be05e", "#ff8a2a"];

function numberTexture(n: number, color: string) {
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(32, 32, 30, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#1a0a05";
  ctx.font = "bold 40px 'Chakra Petch', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(String(n), 32, 35);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** The five prize lines drawn on the glass, with numbered markers on the side pillars. */
export function Paylines({ lines, winLines }: { lines: number; winLines: number[] }) {
  const mats = useMemo(
    () =>
      LINE_COLORS.map(
        (c) =>
          new THREE.MeshBasicMaterial({ color: new THREE.Color(c), toneMapped: false }),
      ),
    [],
  );
  const markerMats = useMemo(
    () =>
      LINE_COLORS.map((c, i) => {
        const tex = numberTexture(i + 1, c);
        return new THREE.MeshStandardMaterial({ map: tex, emissiveMap: tex, emissive: "#ffffff", transparent: true });
      }),
    [],
  );
  const segments = useMemo(
    () =>
      PAYLINES.map((pl, li) => {
        const pts: [number, number][] = [
          [-WIN_W / 2 + 0.02, ROW_Y[pl.rows[0]]!],
          ...pl.rows.map((r, reel) => [REEL_XS[reel]!, ROW_Y[r]!] as [number, number]),
          [WIN_W / 2 - 0.02, ROW_Y[pl.rows[2]]!],
        ];
        return pts.slice(1).map((p, i) => {
          const a = pts[i]!;
          const dx = p[0] - a[0];
          const dy = p[1] - a[1];
          return {
            pos: [(a[0] + p[0]) / 2, WIN_Y + (a[1] + p[1]) / 2, FRONT_Z - 0.008 + li * 0.0006] as [number, number, number],
            len: Math.hypot(dx, dy) + 0.012,
            rot: Math.atan2(dy, dx),
          };
        });
      }),
    [],
  );
  const markers = useMemo(() => {
    const out: { line: number; pos: [number, number, number] }[] = [];
    for (const side of [-1, 1]) {
      const byRow = new Map<number, number[]>();
      PAYLINES.forEach((pl, i) => {
        const row = side < 0 ? pl.rows[0] : pl.rows[2];
        byRow.set(row, [...(byRow.get(row) ?? []), i]);
      });
      for (const [row, ids] of byRow) {
        ids.forEach((li, k) => {
          const x = side * (WIN_W / 2 + 0.115 + (k - (ids.length - 1) / 2) * 0.095);
          out.push({ line: li, pos: [x, WIN_Y + ROW_Y[row]!, FRONT_Z + 0.003] });
        });
      }
    }
    return out;
  }, []);

  const winSet = useMemo(() => new Set(winLines), [winLines]);
  const groups = useRef<(THREE.Group | null)[]>([]);
  const base = useMemo(() => LINE_COLORS.map((c) => new THREE.Color(c)), []);
  useFrame(({ clock }) => {
    const pulse = 0.5 + 0.5 * Math.sin(clock.elapsedTime * 10);
    mats.forEach((m, i) => {
      const active = i < lines;
      const winning = winSet.has(i + 1);
      const g = groups.current[i];
      // While a win shows, only the winning lines stay lit.
      if (g) g.visible = active && (winSet.size === 0 || winning);
      m.color.copy(base[i]!).multiplyScalar(winning ? 1.5 + pulse * 2.5 : 0.85);
    });
    markerMats.forEach((m, i) => {
      const winning = winSet.has(i + 1);
      m.opacity = i < lines ? 1 : 0.25;
      m.emissiveIntensity = winning ? 0.9 + pulse * 1.5 : i < lines ? 0.55 : 0.08;
    });
  });

  return (
    <group>
      {segments.map((segs, li) => (
        <group key={li} ref={(el) => { groups.current[li] = el; }}>
          {segs.map((s, k) => (
            <mesh key={k} position={s.pos} rotation-z={s.rot} material={mats[li]!}>
              <boxGeometry args={[s.len, 0.014, 0.003]} />
            </mesh>
          ))}
        </group>
      ))}
      {markers.map((m, i) => (
        <mesh key={i} position={m.pos} material={markerMats[m.line]!}>
          <circleGeometry args={[0.042, 28]} />
        </mesh>
      ))}
    </group>
  );
}

/** Golden sparkles in the reel window on any win; a shower over the whole machine on big wins. */
export function WinSparkles({ won, big }: { won: boolean; big: boolean }) {
  const flash = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    if (flash.current) flash.current.intensity = big ? 6 + Math.sin(clock.elapsedTime * 16) * 5 : 0;
  });
  return (
    <>
      <Sparkles count={30} scale={[BODY_W, 0.8, 0.6]} position={[0, TOP_Y + 0.5, FRONT_Z + 0.2]} size={2.5} speed={0.3} color="#ffd98a" opacity={0.7} />
      {/* Always mounted (opacity toggled) so their shaders compile up front and a win never hitches. */}
      <Sparkles count={80} scale={[WIN_W, WIN_H, 0.4]} position={[0, WIN_Y, FRONT_Z + 0.15]} size={7} speed={0.9} color="#ffe08a" noise={1.5} opacity={won ? 1 : 0} />
      <Sparkles count={220} scale={[4.5, 4.5, 2.5]} position={[0, 2.4, FRONT_Z]} size={9} speed={1.4} color="#ffcf5a" noise={2} opacity={big ? 1 : 0} />
      <pointLight ref={flash} position={[0, WIN_Y, FRONT_Z + 1.2]} distance={5} color="#ffc24a" intensity={0} />
    </>
  );
}

/* ---------- small cabinet details ---------- */

function useDisplayTexture(credits: number, bet: number, win: number) {
  const canvas = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 1024;
    c.height = 140;
    return c;
  }, []);
  const tex = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, [canvas]);
  useEffect(() => {
    const ctx = canvas.getContext("2d")!;
    const { width: w, height: h } = canvas;
    ctx.fillStyle = "#070303";
    ctx.fillRect(0, 0, w, h);
    const cells: [string, number, number][] = [
      ["CRÉDITO", credits, 6],
      ["APOSTA", bet, 3],
      ["PRÉMIO", win, 5],
    ];
    cells.forEach(([label, value, digits], i) => {
      const cx = (w / 3) * i + w / 6;
      ctx.textAlign = "center";
      ctx.fillStyle = "#c99a3a";
      ctx.font = "600 26px 'Chakra Petch', sans-serif";
      ctx.fillText(label, cx, 34);
      ctx.font = "bold 74px 'Courier New', monospace";
      ctx.fillStyle = "rgba(255,60,40,0.12)";
      ctx.fillText("8".repeat(digits), cx, 116);
      ctx.fillStyle = "#ff4632";
      ctx.shadowColor = "#ff2a1a";
      ctx.shadowBlur = 18;
      ctx.fillText(String(Math.min(value, 10 ** digits - 1)).padStart(digits, "0"), cx, 116);
      ctx.shadowBlur = 0;
    });
    tex.needsUpdate = true;
  }, [canvas, tex, credits, bet, win]);
  return tex;
}

function makeGlassStreak() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 256, 128);
  g.addColorStop(0.18, "rgba(255,255,255,0)");
  g.addColorStop(0.26, "rgba(255,255,255,0.9)");
  g.addColorStop(0.33, "rgba(255,255,255,0)");
  g.addColorStop(0.42, "rgba(255,255,255,0)");
  g.addColorStop(0.45, "rgba(255,255,255,0.5)");
  g.addColorStop(0.49, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 256, 128);
  return new THREE.CanvasTexture(c);
}

export function CabinetExtras({
  credits,
  bet,
  win,
  excited,
  goldMat,
  chromeMat,
}: {
  credits: number;
  bet: number;
  win: number;
  excited: boolean;
  goldMat: THREE.Material;
  chromeMat: THREE.Material;
}) {
  const display = useDisplayTexture(credits, bet, win);
  const streak = useMemo(() => makeGlassStreak(), []);
  const ledMats = useMemo(
    () => [0, 1].map(() => new THREE.MeshStandardMaterial({ color: "#000000", emissive: "#ffb040", toneMapped: false })),
    [],
  );
  const towerRed = useRef<THREE.MeshStandardMaterial>(null);
  const towerWhite = useRef<THREE.MeshStandardMaterial>(null);
  const glow = useRef<THREE.MeshStandardMaterial>(null);
  const tmp = useMemo(() => new THREE.Color(), []);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    ledMats.forEach((m, i) => {
      const hue = excited ? (t * 0.6 + i * 0.5) % 1 : 0.07 + 0.03 * Math.sin(t * 0.8 + i);
      m.emissive.copy(tmp.setHSL(hue, 1, 0.55));
      m.emissiveIntensity = excited ? 2.4 : 1.4;
    });
    const blink = Math.sin(t * (excited ? 14 : 2)) > 0;
    if (towerRed.current) towerRed.current.emissiveIntensity = excited ? (blink ? 3 : 0.3) : 1.1;
    if (towerWhite.current) towerWhite.current.emissiveIntensity = excited ? (blink ? 0.3 : 3) : 0.5;
    if (glow.current) glow.current.emissiveIntensity = 1.6 + Math.sin(t * 1.5) * 0.4;
  });

  const bandY = (WIN_Y + WIN_H / 2 + TOP_Y) / 2;
  return (
    <group>
      {/* credit display above the reels */}
      <mesh position={[0, bandY, FRONT_Z + 0.012]}>
        <boxGeometry args={[1.72, 0.25, 0.02]} />
        <meshStandardMaterial color="#050303" roughness={0.3} metalness={0.4} />
      </mesh>
      <mesh position={[0, bandY, FRONT_Z + 0.023]}>
        <planeGeometry args={[1.64, 0.2]} />
        <meshStandardMaterial map={display} emissiveMap={display} emissive="#ffffff" emissiveIntensity={1.15} roughness={0.2} />
      </mesh>

      {/* glass reflection streak */}
      <mesh position={[0, WIN_Y, FRONT_Z + 0.008]} renderOrder={3}>
        <planeGeometry args={[WIN_W, WIN_H]} />
        <meshBasicMaterial map={streak} transparent opacity={0.09} blending={THREE.AdditiveBlending} depthWrite={false} />
      </mesh>

      {/* side LED strips */}
      {[-1, 1].map((s, i) => (
        <mesh key={s} position={[s * (BODY_W / 2 + 0.004), (BASE_H + TOP_Y) / 2, FRONT_Z - 0.1]} material={ledMats[i]!}>
          <boxGeometry args={[0.012, TOP_Y - BASE_H - 0.1, 0.035]} />
        </mesh>
      ))}

      {/* gold pinstripe frames on the side panels */}
      {[-1, 1].map((s) =>
        (
          [
            [0, 3.15, 1.3, 0.025],
            [0, 1.1, 1.3, 0.025],
            [-0.65, 2.125, 0.025, 2.05],
            [0.65, 2.125, 0.025, 2.05],
          ] as const
        ).map(([z, y, dz, dy], k) => (
          <mesh key={`${s}-${k}`} position={[s * (BODY_W / 2 + 0.003), y, z - 0.05]} material={goldMat}>
            <boxGeometry args={[0.006, dy, dz]} />
          </mesh>
        )),
      )}

      {/* coin slot + bill acceptor */}
      <group position={[0.82, TRAY.floorY + 0.3, FRONT_Z + 0.01]}>
        <mesh material={chromeMat}>
          <boxGeometry args={[0.2, 0.26, 0.02]} />
        </mesh>
        <mesh position={[0, 0.05, 0.011]}>
          <boxGeometry args={[0.025, 0.1, 0.004]} />
          <meshStandardMaterial color="#050505" />
        </mesh>
        <mesh position={[0, -0.08, 0.012]}>
          <boxGeometry args={[0.13, 0.018, 0.004]} />
          <meshStandardMaterial ref={glow} color="#000" emissive="#35ff7a" toneMapped={false} />
        </mesh>
      </group>
      <pointLight position={[0, TRAY.floorY + 0.5, FRONT_Z + 0.5]} intensity={0.35} distance={1.4} color="#ffd9a0" />

      {/* tower light */}
      <group position={[BODY_W / 2 - 0.3, TOP_Y + 0.95, 0]}>
        <mesh position-y={0.03} material={chromeMat}>
          <cylinderGeometry args={[0.1, 0.11, 0.06, 32]} />
        </mesh>
        <mesh position-y={0.15}>
          <cylinderGeometry args={[0.075, 0.075, 0.18, 32]} />
          <meshStandardMaterial ref={towerRed} color="#5a0505" emissive="#ff2a1a" toneMapped={false} transparent opacity={0.95} />
        </mesh>
        <mesh position-y={0.33}>
          <cylinderGeometry args={[0.075, 0.075, 0.18, 32]} />
          <meshStandardMaterial ref={towerWhite} color="#666" emissive="#fff4dc" toneMapped={false} transparent opacity={0.95} />
        </mesh>
        <mesh position-y={0.44} material={chromeMat}>
          <sphereGeometry args={[0.078, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
        </mesh>
      </group>

      {/* underglow on the carpet */}
      <mesh position={[0, 0.03, FRONT_Z + 0.08]}>
        <boxGeometry args={[BODY_W + 0.1, 0.02, 0.01]} />
        <meshStandardMaterial color="#000" emissive="#ff5a2a" emissiveIntensity={2} toneMapped={false} />
      </mesh>
      <pointLight position={[0, 0.12, FRONT_Z + 0.35]} intensity={1.6} distance={2.6} color="#ff6a3a" />
    </group>
  );
}
