import { useCallback, useEffect, useRef, useState } from "react";
import {
  LINE_OPTIONS,
  MAX_BET,
  MIN_BET,
  REEL_STRIPS,
  STARTING_CREDITS,
  canSpin,
  clampBet,
  evaluateGrid,
  gridFromStops,
  totalBet,
  type FullSpinResult,
} from "@/lib/slot";
import { playCoins, playSpin, playStop, playWin } from "@/lib/sound";
import { duckMusic, startMusic, stopMusic } from "@/lib/music";
import { coinCountForWin } from "./coinSim";

const STORAGE_KEY = "slot-credits";
const MUSIC_KEY = "slot-music";
/** How long each reel spins before it lands, left to right. */
export const REEL_SPIN_MS = [1900, 2450, 3000];
/** Stops showing 7-7-7 on the middle line when the game first opens. */
export const INITIAL_STOPS = [7, 10, 11];

export interface SpinCommand {
  id: number;
  stops: number[];
}

export function useSlotGame() {
  const [credits, setCredits] = useState(STARTING_CREDITS);
  const [bet, setBetState] = useState(1);
  const [lines, setLines] = useState<number>(5);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<FullSpinResult | null>(null);
  const [lastWin, setLastWin] = useState(0);
  const [muted, setMuted] = useState(false);
  const [music, setMusic] = useState(true);
  const [command, setCommand] = useState<SpinCommand>({ id: 0, stops: INITIAL_STOPS });
  const loaded = useRef(false);
  const musicStarted = useRef(false);

  useEffect(() => {
    const saved = Number(window.localStorage.getItem(STORAGE_KEY));
    if (Number.isFinite(saved) && saved > 0) setCredits(saved);
    if (window.localStorage.getItem(MUSIC_KEY) === "off") setMusic(false);
    loaded.current = true;
    return () => stopMusic();
  }, []);

  useEffect(() => {
    if (loaded.current) window.localStorage.setItem(STORAGE_KEY, String(credits));
  }, [credits]);

  // Browsers only allow audio after a tap/click, so music starts on the first gesture.
  useEffect(() => {
    if (!music) return;
    const begin = () => {
      musicStarted.current = true;
      startMusic();
    };
    if (musicStarted.current) {
      startMusic();
      return;
    }
    window.addEventListener("pointerdown", begin, { once: true });
    window.addEventListener("keydown", begin, { once: true });
    return () => {
      window.removeEventListener("pointerdown", begin);
      window.removeEventListener("keydown", begin);
    };
  }, [music]);

  const cost = totalBet(bet, lines);

  const spin = useCallback(() => {
    if (spinning || !canSpin(credits, cost)) return;
    setSpinning(true);
    setResult(null);
    setLastWin(0);
    setCredits((c) => c - cost);
    const stops = REEL_STRIPS.map((strip) => Math.floor(Math.random() * strip.length));
    const grid = gridFromStops(stops);
    setCommand((c) => ({ id: c.id + 1, stops }));
    const last = REEL_SPIN_MS[REEL_SPIN_MS.length - 1]!;
    if (!muted) {
      playSpin(last);
      REEL_SPIN_MS.forEach((ms) => playStop(ms));
    }
    window.setTimeout(() => {
      const r = evaluateGrid(grid, bet, lines);
      setResult(r);
      setLastWin(r.total);
      if (r.total > 0) {
        setCredits((c) => c + r.total);
        if (!muted) {
          duckMusic(r.kind === "jackpot" ? 4000 : 1800);
          playWin(r.kind === "jackpot" || r.kind === "three");
          playCoins(coinCountForWin(r.total));
        }
      }
      setSpinning(false);
    }, last + 150);
  }, [spinning, credits, cost, bet, lines, muted]);

  const changeBet = useCallback(
    (delta: number) => {
      if (!spinning) setBetState((b) => clampBet(b + delta));
    },
    [spinning],
  );

  const cycleLines = useCallback(() => {
    if (spinning) return;
    setLines((l) => {
      const i = LINE_OPTIONS.indexOf(l as (typeof LINE_OPTIONS)[number]);
      return LINE_OPTIONS[(i + 1) % LINE_OPTIONS.length]!;
    });
  }, [spinning]);

  return {
    credits,
    bet,
    lines,
    cost,
    spinning,
    result,
    lastWin,
    muted,
    music,
    command,
    broke: !spinning && credits < MIN_BET,
    canSpin: !spinning && canSpin(credits, cost),
    spin,
    changeBet,
    cycleLines,
    maxBet: () => {
      if (spinning) return;
      setLines(5);
      setBetState(Math.max(MIN_BET, Math.min(MAX_BET, Math.floor(credits / 5))));
    },
    toggleMute: () => setMuted((m) => !m),
    toggleMusic: () =>
      setMusic((m) => {
        const next = !m;
        window.localStorage.setItem(MUSIC_KEY, next ? "on" : "off");
        if (next) {
          musicStarted.current = true;
          startMusic();
        } else stopMusic();
        return next;
      }),
    refill: () => {
      setCredits(STARTING_CREDITS);
      setResult(null);
    },
  };
}
