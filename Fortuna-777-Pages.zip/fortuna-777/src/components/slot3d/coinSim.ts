/** Tiny coin physics: coins drop from the chute, tumble, bounce off the tray walls and settle flat in a pile. */
export const MAX_COINS = 70;
const GRAVITY = 9.8 * 1.4;
const BOUNCE = 0.3;
const WALL_BOUNCE = 0.4;
const FRICTION = 7;
export const COIN_RADIUS = 0.065;
export const COIN_THICK = 0.016;

export interface Tray {
  floorY: number;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface Coin {
  p: [number, number, number];
  v: [number, number, number];
  rot: [number, number, number];
  spin: [number, number, number];
  delay: number;
  /** Stack layer so settled coins pile instead of sharing one plane. */
  layer: number;
  resting: boolean;
}

export function coinCountForWin(win: number): number {
  return Math.min(MAX_COINS, Math.max(6, Math.round(win * 1.5)));
}

export function spawnCoins(
  count: number,
  chute: [number, number, number],
  rand: () => number = Math.random,
): Coin[] {
  return Array.from({ length: Math.min(count, MAX_COINS) }, (_, i) => ({
    p: [chute[0] + (rand() - 0.5) * 0.5, chute[1], chute[2]],
    v: [(rand() - 0.5) * 1.2, rand() * 0.6, 0.5 + rand() * 1.0],
    rot: [rand() * Math.PI, rand() * Math.PI, rand() * Math.PI],
    spin: [(rand() - 0.5) * 18, (rand() - 0.5) * 10, (rand() - 0.5) * 18],
    delay: i * 0.05,
    layer: Math.floor(rand() * Math.min(5, 1 + count / 12)),
    resting: false,
  }));
}

export function stepCoins(coins: Coin[], dt: number, tray: Tray) {
  for (const c of coins) {
    if (c.delay > 0) {
      c.delay -= dt;
      continue;
    }
    if (c.resting) continue;
    const rest = tray.floorY + COIN_THICK / 2 + c.layer * COIN_THICK * 0.9;
    c.v[1] -= GRAVITY * dt;
    for (let k = 0; k < 3; k++) {
      c.p[k]! += c.v[k]! * dt;
      c.rot[k]! += c.spin[k]! * dt;
    }
    const r = COIN_RADIUS;
    if (c.p[0] < tray.minX + r) { c.p[0] = tray.minX + r; c.v[0] = Math.abs(c.v[0]) * WALL_BOUNCE; }
    if (c.p[0] > tray.maxX - r) { c.p[0] = tray.maxX - r; c.v[0] = -Math.abs(c.v[0]) * WALL_BOUNCE; }
    if (c.p[2] < tray.minZ + r) { c.p[2] = tray.minZ + r; c.v[2] = Math.abs(c.v[2]) * WALL_BOUNCE; }
    if (c.p[2] > tray.maxZ - r) { c.p[2] = tray.maxZ - r; c.v[2] = -Math.abs(c.v[2]) * WALL_BOUNCE; }
    if (c.p[1] <= rest) {
      c.p[1] = rest;
      if (Math.abs(c.v[1]) > 0.7) {
        c.v[1] = -c.v[1] * BOUNCE;
        c.spin = c.spin.map((s) => s * 0.5) as Coin["spin"];
      } else {
        c.v[1] = 0;
        const f = Math.exp(-FRICTION * dt);
        c.v[0] *= f;
        c.v[2] *= f;
        c.rot[0] *= f;
        c.rot[2] *= f;
        c.spin = [0, c.spin[1] * f, 0];
        if (Math.hypot(c.v[0], c.v[2]) < 0.02) {
          c.rot[0] = 0;
          c.rot[2] = 0;
          c.resting = true;
        }
      }
    }
  }
}
