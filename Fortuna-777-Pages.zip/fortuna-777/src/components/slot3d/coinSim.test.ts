import { describe, expect, it } from "vitest";
import { COIN_RADIUS, MAX_COINS, coinCountForWin, spawnCoins, stepCoins } from "./coinSim";

const tray = { floorY: 1.3, minX: -0.6, maxX: 0.6, minZ: 0.93, maxZ: 1.28 };

describe("coin shower", () => {
  it("bigger wins drop more coins, capped", () => {
    expect(coinCountForWin(2)).toBe(6);
    expect(coinCountForWin(30)).toBe(45);
    expect(coinCountForWin(2500)).toBe(MAX_COINS);
  });
  it("coins settle flat inside the tray", () => {
    const coins = spawnCoins(40, [0, 1.55, 0.94]);
    for (let i = 0; i < 900; i++) stepCoins(coins, 1 / 60, tray);
    for (const c of coins) {
      expect(c.resting).toBe(true);
      expect(c.rot[0]).toBe(0);
      expect(c.p[1]).toBeGreaterThan(tray.floorY);
      expect(c.p[1]).toBeLessThan(tray.floorY + 0.1);
      expect(c.p[0]).toBeGreaterThanOrEqual(tray.minX + COIN_RADIUS);
      expect(c.p[0]).toBeLessThanOrEqual(tray.maxX - COIN_RADIUS);
      expect(c.p[2]).toBeLessThanOrEqual(tray.maxZ - COIN_RADIUS);
    }
  });
});
