import { REEL_STRIPS } from "@/lib/slot";

/* ---------- physical dimensions (scene units ≈ metres × 1.4) ---------- */
export const BODY_W = 2.4;
export const BODY_D = 1.8;
export const FRONT_Z = BODY_D / 2;
export const BASE_H = 0.9;
export const WIN_Y = 2.6;
export const WIN_H = 0.95;
export const WIN_W = 1.95;
export const TOP_Y = 3.45;
export const REEL_R = 0.8;
export const REEL_Z = 0.05;
export const REEL_W = 0.58;
export const REEL_XS = [-0.64, 0, 0.64];
export const STOPS = REEL_STRIPS[0]!.length;
export const STEP = (Math.PI * 2) / STOPS;
export const CELL_H = 2 * REEL_R * Math.tan(STEP / 2);
/** Extra full turns per reel so later reels spin longer. */
export const SPIN_TURNS = [3, 4, 5];
/** Coin tray in front of the lower cabinet. */
export const TRAY = { floorY: 1.3, minX: -0.6, maxX: 0.6, minZ: FRONT_Z + 0.01, maxZ: FRONT_Z + 0.36 };

