import * as THREE from "three";
import { SYMBOL_BY_ID, type SymbolId } from "@/lib/slot";

const EMOJI_FONT = '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';

function toTexture(canvas: HTMLCanvasElement) {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function grain(ctx: CanvasRenderingContext2D, w: number, h: number, alpha: number, count: number) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = `rgba(${Math.random() > 0.5 ? "0,0,0" : "255,255,255"},${alpha * Math.random()})`;
    ctx.fillRect(Math.random() * w, Math.random() * h, 1.5, 1.5);
  }
}

export function makeSymbolTexture(id: SymbolId, aspect: number) {
  const w = 512;
  const h = Math.round(w / aspect);
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  const bg = ctx.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, "#efe4cc");
  bg.addColorStop(0.5, "#fffaf0");
  bg.addColorStop(1, "#efe4cc");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  grain(ctx, w, h, 0.06, 2500);
  ctx.fillStyle = "rgba(120,95,60,0.35)";
  ctx.fillRect(0, 0, w, 2);
  ctx.fillRect(0, h - 2, w, 2);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  if (id === "seven") {
    ctx.font = `${Math.round(h * 0.9)}px Bungee, Impact, sans-serif`;
    ctx.lineJoin = "round";
    ctx.lineWidth = 14;
    ctx.strokeStyle = "#b8862b";
    ctx.strokeText("7", w / 2, h * 0.54);
    const red = ctx.createLinearGradient(0, h * 0.15, 0, h * 0.9);
    red.addColorStop(0, "#ff4a3d");
    red.addColorStop(1, "#9c0f12");
    ctx.fillStyle = red;
    ctx.fillText("7", w / 2, h * 0.54);
  } else {
    ctx.font = `${Math.round(h * 0.78)}px ${EMOJI_FONT}`;
    ctx.shadowColor = "rgba(0,0,0,0.25)";
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 4;
    ctx.fillText(SYMBOL_BY_ID[id].glyph, w / 2, h * 0.54);
  }
  return toTexture(c);
}

export function makeMarqueeTexture() {
  const w = 1024;
  const h = 360;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  const bg = ctx.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, w * 0.6);
  bg.addColorStop(0, "#7a0d16");
  bg.addColorStop(1, "#22040a");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  // sunburst rays
  ctx.save();
  ctx.translate(w / 2, h * 0.55);
  for (let i = 0; i < 36; i++) {
    ctx.rotate((Math.PI * 2) / 36);
    ctx.fillStyle = i % 2 ? "rgba(255,200,90,0.06)" : "rgba(0,0,0,0.08)";
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(w, -40);
    ctx.lineTo(w, 40);
    ctx.fill();
  }
  ctx.restore();
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.font = "150px Bungee, Impact, sans-serif";
  ctx.lineJoin = "round";
  ctx.lineWidth = 18;
  ctx.strokeStyle = "#2a0508";
  ctx.strokeText("FORTUNA", w / 2, h * 0.4);
  const gold = ctx.createLinearGradient(0, h * 0.18, 0, h * 0.62);
  gold.addColorStop(0, "#fff3b8");
  gold.addColorStop(0.5, "#f2c14e");
  gold.addColorStop(1, "#a8701c");
  ctx.fillStyle = gold;
  ctx.shadowColor = "rgba(255,190,60,0.8)";
  ctx.shadowBlur = 24;
  ctx.fillText("FORTUNA", w / 2, h * 0.4);
  ctx.shadowBlur = 0;
  ctx.font = "92px Bungee, Impact, sans-serif";
  ctx.lineWidth = 12;
  ctx.strokeText("777", w / 2, h * 0.78);
  const red = ctx.createLinearGradient(0, h * 0.66, 0, h * 0.92);
  red.addColorStop(0, "#ff6b52");
  red.addColorStop(1, "#c4141a");
  ctx.fillStyle = red;
  ctx.fillText("777", w / 2, h * 0.78);
  return toTexture(c);
}

export function makeCarpetTexture() {
  const s = 256;
  const c = document.createElement("canvas");
  c.width = s;
  c.height = s;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#2a080e";
  ctx.fillRect(0, 0, s, s);
  ctx.strokeStyle = "#8a6a2c";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(s / 2, 10);
  ctx.lineTo(s - 10, s / 2);
  ctx.lineTo(s / 2, s - 10);
  ctx.lineTo(10, s / 2);
  ctx.closePath();
  ctx.stroke();
  ctx.fillStyle = "#0d3236";
  ctx.beginPath();
  ctx.arc(s / 2, s / 2, 34, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#8a6a2c";
  for (const [x, y] of [[0, 0], [s, 0], [0, s], [s, s]] as const) {
    ctx.beginPath();
    ctx.arc(x, y, 18, 0, Math.PI * 2);
    ctx.fill();
  }
  grain(ctx, s, s, 0.25, 6000);
  const t = toTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(26, 26);
  return t;
}

/** Darkens the top and bottom of the reel window like the curved drums do in a real cabinet. */
export function makeShadeTexture() {
  const c = document.createElement("canvas");
  c.width = 4;
  c.height = 256;
  const ctx = c.getContext("2d")!;
  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, "rgba(0,0,0,0.8)");
  g.addColorStop(0.2, "rgba(0,0,0,0)");
  g.addColorStop(0.8, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.8)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 4, 256);
  return toTexture(c);
}
