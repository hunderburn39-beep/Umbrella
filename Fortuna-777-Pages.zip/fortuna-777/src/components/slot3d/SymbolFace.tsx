import { SYMBOL_BY_ID, type SymbolId } from "@/lib/slot";
import { cn } from "@/lib/utils";

export function SymbolFace({ id, className }: { id: SymbolId; className?: string }) {
  if (id === "seven") {
    return (
      <span className={cn("font-display leading-none text-ruby drop-shadow-sm", className)}>7</span>
    );
  }
  return (
    <span className={cn("leading-none", className)} role="img" aria-label={SYMBOL_BY_ID[id].label}>
      {SYMBOL_BY_ID[id].glyph}
    </span>
  );
}

