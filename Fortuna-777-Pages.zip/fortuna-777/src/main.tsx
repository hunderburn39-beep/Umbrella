import { createRoot } from "react-dom/client";
import { SlotGame3D } from "./components/slot3d/SlotGame3D";
import "./styles.css";
createRoot(document.getElementById("root")!).render(<SlotGame3D />);
