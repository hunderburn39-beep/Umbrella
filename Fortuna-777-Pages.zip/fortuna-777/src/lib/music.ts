/** Background casino music: one looping track, faded in/out, ducked under big wins. */
const SRC = `${import.meta.env.BASE_URL}audio/casino-jazz.mp3`;
const VOLUME = 0.32;
let el: HTMLAudioElement | null = null;
let fadeTimer: number | undefined;

function audio() {
  if (typeof window === "undefined") return null;
  if (!el) {
    el = new Audio(SRC);
    el.loop = true;
    el.preload = "auto";
    el.volume = 0;
  }
  return el;
}

function fadeTo(target: number, ms: number, then?: () => void) {
  const a = audio();
  if (!a) return;
  window.clearInterval(fadeTimer);
  const start = a.volume;
  const t0 = performance.now();
  fadeTimer = window.setInterval(() => {
    const k = Math.min(1, (performance.now() - t0) / ms);
    a.volume = start + (target - start) * k;
    if (k >= 1) {
      window.clearInterval(fadeTimer);
      then?.();
    }
  }, 40);
}

export function startMusic() {
  const a = audio();
  if (!a) return;
  void a.play().then(() => fadeTo(VOLUME, 1200)).catch(() => {});
}

export function stopMusic() {
  const a = audio();
  if (!a) return;
  fadeTo(0, 500, () => a.pause());
}

/** Lowers the music for a moment so the win jingle stands out. */
export function duckMusic(ms = 1800) {
  const a = audio();
  if (!a || a.paused) return;
  fadeTo(VOLUME * 0.3, 150, () => window.setTimeout(() => fadeTo(VOLUME, 800), ms));
}
