export type SymbolId = "cherry" | "lemon" | "orange" | "grape" | "bell" | "star" | "seven";

export interface SlotSymbol {
  id: SymbolId;
  glyph: string;
  label: string;
  weight: number;
  /** Multiplier of the bet for three of a kind on the payline. */
  payout: number;
}

export const SYMBOLS: SlotSymbol[] = [
  { id: "cherry", glyph: "🍒", label: "Cereja", weight: 30, payout: 5 },
  { id: "lemon", glyph: "🍋", label: "Limão", weight: 25, payout: 10 },
  { id: "orange", glyph: "🍊", label: "Laranja", weight: 20, payout: 15 },
  { id: "grape", glyph: "🍇", label: "Uvas", weight: 14, payout: 25 },
  { id: "bell", glyph: "🔔", label: "Sino", weight: 7, payout: 50 },
  { id: "star", glyph: "⭐", label: "Estrela", weight: 3, payout: 100 },
  { id: "seven", glyph: "7", label: "Sete", weight: 1, payout: 250 },
];

export const SYMBOL_BY_ID = Object.fromEntries(SYMBOLS.map((s) => [s.id, s])) as Record<
  SymbolId,
  SlotSymbol
>;

export const STARTING_CREDITS = 100;
export const MIN_BET = 1;
export const MAX_BET = 10;
/** Two cherries anywhere on the payline pay this multiple of the bet. */
export const TWO_CHERRIES_MULTIPLIER = 2;

const TOTAL_WEIGHT = SYMBOLS.reduce((sum, s) => sum + s.weight, 0);

export function randomSymbol(rand: () => number = Math.random): SymbolId {
  let roll = rand() * TOTAL_WEIGHT;
  for (const s of SYMBOLS) {
    roll -= s.weight;
    if (roll < 0) return s.id;
  }
  return SYMBOLS[0]!.id;
}

export function clampBet(bet: number): number {
  return Math.min(MAX_BET, Math.max(MIN_BET, Math.round(bet)));
}

export function canSpin(credits: number, bet: number): boolean {
  return credits >= bet && bet >= MIN_BET;
}

export interface SpinResult {
  win: number;
  kind: "jackpot" | "three" | "cherries" | "none";
}

export function evaluateLine(line: SymbolId[], bet: number): SpinResult {
  const [a, b, c] = line;
  if (a && a === b && b === c) {
    const sym = SYMBOL_BY_ID[a];
    return { win: bet * sym.payout, kind: a === "seven" ? "jackpot" : "three" };
  }
  const cherries = line.filter((s) => s === "cherry").length;
  if (cherries >= 2) return { win: bet * TWO_CHERRIES_MULTIPLIER, kind: "cherries" };
  return { win: 0, kind: "none" };
}

/** Printed order of symbols around each physical reel (20 stops). Every symbol appears on every reel. */
export const REEL_STRIPS: SymbolId[][] = [
  ["cherry", "lemon", "orange", "grape", "cherry", "bell", "lemon", "seven", "cherry", "orange",
   "grape", "lemon", "star", "cherry", "orange", "bell", "lemon", "grape", "cherry", "star"],
  ["lemon", "cherry", "grape", "bell", "orange", "cherry", "star", "lemon", "grape", "cherry",
   "seven", "orange", "lemon", "cherry", "bell", "grape", "orange", "star", "lemon", "cherry"],
  ["orange", "cherry", "lemon", "star", "grape", "cherry", "bell", "orange", "lemon", "cherry",
   "grape", "seven", "lemon", "cherry", "orange", "bell", "grape", "star", "lemon", "cherry"],
];

/** Picks a stop on the strip that shows `symbol` on the payline. */
export function stopIndexFor(strip: SymbolId[], symbol: SymbolId, rand: () => number = Math.random): number {
  const matches = strip.flatMap((s, i) => (s === symbol ? [i] : []));
  if (matches.length === 0) throw new Error(`Symbol ${symbol} missing from strip`);
  return matches[Math.floor(rand() * matches.length)]!;
}

/* ---------------- 5 paylines ---------------- */

/** Row index per reel: 0 = top, 1 = middle, 2 = bottom. */
export interface Payline {
  id: number;
  name: string;
  rows: [number, number, number];
}

export const PAYLINES: Payline[] = [
  { id: 1, name: "Meio", rows: [1, 1, 1] },
  { id: 2, name: "Cima", rows: [0, 0, 0] },
  { id: 3, name: "Baixo", rows: [2, 2, 2] },
  { id: 4, name: "V", rows: [0, 2, 0] },
  { id: 5, name: "V invertido", rows: [2, 0, 2] },
];

export const LINE_OPTIONS = [1, 3, 5] as const;

export function totalBet(betPerLine: number, lines: number): number {
  return betPerLine * lines;
}

/** Visible 3×3 window for the given reel stops: grid[row][reel]. Row 0 is the symbol above the stop. */
export function gridFromStops(stops: number[], strips: SymbolId[][] = REEL_STRIPS): SymbolId[][] {
  return [-1, 0, 1].map((offset) =>
    stops.map((stop, reel) => {
      const strip = strips[reel]!;
      return strip[(stop + offset + strip.length) % strip.length]!;
    }),
  );
}

export interface LineWin {
  line: number;
  win: number;
  kind: SpinResult["kind"];
}

export interface FullSpinResult {
  total: number;
  kind: SpinResult["kind"];
  lineWins: LineWin[];
}

/** Pays every active line (the first `lines` paylines) at `betPerLine` each. */
export function evaluateGrid(grid: SymbolId[][], betPerLine: number, lines: number): FullSpinResult {
  const lineWins: LineWin[] = [];
  for (const pl of PAYLINES.slice(0, lines)) {
    const symbols = pl.rows.map((row, reel) => grid[row]![reel]!);
    const r = evaluateLine(symbols, betPerLine);
    if (r.win > 0) lineWins.push({ line: pl.id, win: r.win, kind: r.kind });
  }
  const rank = { jackpot: 3, three: 2, cherries: 1, none: 0 } as const;
  const kind = lineWins.reduce<SpinResult["kind"]>((k, w) => (rank[w.kind] > rank[k] ? w.kind : k), "none");
  return { total: lineWins.reduce((s, w) => s + w.win, 0), kind, lineWins };
}
