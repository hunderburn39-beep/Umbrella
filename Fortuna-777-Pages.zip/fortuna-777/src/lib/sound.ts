let ctx: AudioContext | null = null;
function ac() {
  if (typeof window === "undefined") return null;
  ctx ??= new AudioContext();
  return ctx;
}
function tone(freq: number, start: number, dur: number, type: OscillatorType = "square", vol = 0.06) {
  const c = ac();
  if (!c) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.value = freq;
  const t = c.currentTime + start;
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(c.destination);
  o.start(t);
  o.stop(t + dur);
}
export function playSpin(ms: number) {
  for (let t = 0; t < ms / 1000; t += 0.07) tone(180 + Math.random() * 60, t, 0.04, "square", 0.03);
}
export function playStop(delayMs: number) {
  tone(120, delayMs / 1000, 0.12, "triangle", 0.12);
}
export function playWin(big: boolean) {
  const notes = big ? [523, 659, 784, 1047, 784, 1047, 1319] : [523, 659, 784];
  notes.forEach((n, i) => tone(n, i * 0.11, 0.18, "triangle", 0.09));
}
export function playCoins(count: number) {
  const n = Math.min(count, 24);
  for (let i = 0; i < n; i++) {
    const t = 0.25 + i * 0.045 + Math.random() * 0.03;
    tone(2400 + Math.random() * 1600, t, 0.06, "sine", 0.04);
    tone(4200 + Math.random() * 1200, t + 0.01, 0.04, "sine", 0.02);
  }
}
