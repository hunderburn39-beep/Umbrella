import { describe, expect, it } from "vitest";
import { canSpin, clampBet, evaluateLine, randomSymbol } from "./slot";

describe("slot rules", () => {
  it("three sevens pay 250x the bet", () => {
    expect(evaluateLine(["seven", "seven", "seven"], 2)).toEqual({ win: 500, kind: "jackpot" });
  });
  it("three lemons pay 10x the bet", () => {
    expect(evaluateLine(["lemon", "lemon", "lemon"], 3).win).toBe(30);
  });
  it("two cherries pay 2x the bet", () => {
    expect(evaluateLine(["cherry", "bell", "cherry"], 3)).toEqual({ win: 6, kind: "cherries" });
  });
  it("a mixed line pays nothing", () => {
    expect(evaluateLine(["cherry", "bell", "lemon"], 5).win).toBe(0);
  });
  it("bet stays between 1 and 10", () => {
    expect(clampBet(0)).toBe(1);
    expect(clampBet(25)).toBe(10);
  });
  it("cannot spin with fewer credits than the bet", () => {
    expect(canSpin(4, 5)).toBe(false);
    expect(canSpin(5, 5)).toBe(true);
  });
  it("random picks the rarest symbol at the top of the range", () => {
    expect(randomSymbol(() => 0)).toBe("cherry");
    expect(randomSymbol(() => 0.9999)).toBe("seven");
  });
});

import { REEL_STRIPS, SYMBOLS, stopIndexFor } from "./slot";
describe("reel strips", () => {
  it("every reel carries every symbol", () => {
    for (const strip of REEL_STRIPS) {
      for (const s of SYMBOLS) expect(strip).toContain(s.id);
    }
  });
  it("the chosen stop shows the drawn symbol", () => {
    for (const strip of REEL_STRIPS) {
      for (const s of SYMBOLS) expect(strip[stopIndexFor(strip, s.id)]).toBe(s.id);
    }
  });
});

import { PAYLINES, evaluateGrid, gridFromStops, totalBet } from "./slot";
import type { SymbolId } from "./slot";

const G = (rows: string[][]) => rows as SymbolId[][];

describe("5 paylines", () => {
  it("has middle, top, bottom, V and inverted V", () => {
    expect(PAYLINES.map((p) => p.rows)).toEqual([
      [1, 1, 1], [0, 0, 0], [2, 2, 2], [0, 2, 0], [2, 0, 2],
    ]);
  });
  it("total cost is bet per line times lines", () => {
    expect(totalBet(2, 5)).toBe(10);
    expect(totalBet(3, 1)).toBe(9 / 3);
  });
  it("the V line pays top-bottom-top", () => {
    const grid = G([["bell", "lemon", "bell"], ["grape", "orange", "cherry"], ["lemon", "bell", "star"]]);
    expect(evaluateGrid(grid, 2, 5)).toMatchObject({ total: 100, lineWins: [{ line: 4, win: 100 }] });
  });
  it("the inverted V line pays bottom-top-bottom", () => {
    const grid = G([["lemon", "star", "grape"], ["grape", "orange", "lemon"], ["star", "bell", "star"]]);
    expect(evaluateGrid(grid, 1, 5)).toMatchObject({ total: 100, lineWins: [{ line: 5 }] });
  });
  it("inactive lines do not pay", () => {
    const grid = G([["bell", "lemon", "bell"], ["grape", "orange", "cherry"], ["lemon", "bell", "star"]]);
    expect(evaluateGrid(grid, 2, 3).total).toBe(0);
  });
  it("several lines add up", () => {
    const grid = G([["lemon", "lemon", "lemon"], ["seven", "seven", "seven"], ["grape", "orange", "bell"]]);
    expect(evaluateGrid(grid, 1, 5)).toMatchObject({ total: 260, kind: "jackpot" });
  });
  it("the window shows the symbols around each stop", () => {
    expect(gridFromStops([7, 10, 11])[1]).toEqual(["seven", "seven", "seven"]);
    expect(gridFromStops([0, 0, 0])[0]).toEqual(["star", "cherry", "cherry"]);
  });
});
